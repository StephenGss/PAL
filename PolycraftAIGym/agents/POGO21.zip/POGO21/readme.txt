./ff -o POGO21_domain.pddl -f POGO21_problem_5_4_4_1.pddl



